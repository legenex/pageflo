# Execution decisions

Record only new decisions discovered during implementation that clarify the approved plan. Do not duplicate the locked discovery.

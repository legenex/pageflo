repo: legenex/legalos
branch: main
path: src

## Reference repo (visual source of truth)
repo: legenex/legenex-dashflo
branch: main
path: client/src

## Last sync
date: 2026-09-01T06:59:00Z

### Updated in this project
- Replaced the invented inline row expansion on Leads with the real lead detail modal from dashflo `components/leads/LeadDetailModal.jsx`: 760px/85vh popover, mono lead id + status pill + delivery in the header, supplier — timestamp subline, Summary / System Response / HLR Trace / CAPI Log / Delivery Log tabs, two-column uppercase-label + mono-value field grid with Arrange, Lead Data section, delivery status list, and the Edit / Resend / Copy payload / Copy response / Archive / Delete footer.
- Rebuilt the PageFlo app shell against dashflo `components/layout/Sidebar.jsx`, `navConfig.js`, `SubNavShell.jsx`, `SystemClock.jsx`, `ViewAsSwitcher.jsx`, `SidebarProfile.jsx`, `AppLayout.jsx`: accordion nav groups with chevron toggles, red active bar, indented children, Collapse/Expand All, View as Owner, profile card, bell + clock + collapse row, red resize grip, 248/68px widths, rounded sidebar edge.
- Removed the invented top app bar: page titles now render in-content like dashflo `SectionHeader`, and canvas radii follow `--radius: 0.625rem` (10px) with the 180deg card gradient.
- Rebuilt Leads on the real anatomy: sub-nav rail with count pills (`LeadsNav.jsx`), filter panel, stats strip, table card with pagination footer, LEADS TELEMETRY footer (`LeadsShell.jsx`), floating assistant button.
- Read the DashFlo design system (`client/src/index.css`, Leads page, sidebar profile, button/badge/card/input primitives) and rebuilt its palette, density and component language as PageFlo.
- Read the LegalOS functional model (`src/collections/Leads.ts`, `FunnelQuizzes.ts`, `FunnelQuizTemplates.ts`, `src/app/(app)/admin/(top)/overview/page.tsx`, `src/components/app/Sidebar.tsx`) and mapped its real fields and routes onto the redesign.
- Produced three design artifacts: PageFlo App (shell + Overview, Leads, Sites, Quizzes, Quiz Builder, Landing Pages, Settings), PageFlo Marketing, PageFlo Privacy.
- No repository writes were made; these files are the design specification for the implementation pass.

## Screen map
| Screen | Built from |
| --- | --- |
| App shell / sidebar / profile menu | dashflo `components/layout/Sidebar.jsx`, `SidebarProfile.jsx`; legalos `components/app/Sidebar.tsx` |
| Overview | legalos `admin/(top)/overview/page.tsx`; dashflo Overview screenshot |
| Leads | dashflo `pages/Leads.jsx` + All Leads screenshot; legalos `collections/Leads.ts` |
| Sites | legalos `admin/(top)/sites/page.tsx`, `collections/Sites.ts` |
| Quizzes + Deployments | legalos `admin/(top)/quizzes/page.tsx`, `collections/FunnelQuizzes.ts`, `FunnelQuizDeployments.ts` |
| Quiz Builder | legalos `components/builder/quiz/*`, `lib/quiz-graph.ts`, `lib/quiz-flow/*` |
| Landing Pages | legalos `admin/(top)/landing-pages/page.tsx`, `collections/FunnelLandingPages.ts` |
| Settings | legalos `admin/(top)/settings/*`; dashflo Settings screenshot |
| Marketing site | replaces legalos `components/LegalOSMarketing.tsx`; dashflo marketing screenshot |
| Privacy | no verified PageFlo legal facts in repo — TODOs marked in the page |
